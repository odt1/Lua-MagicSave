export interface ICheckVersionResponse {
    isvalid: boolean;
    latestVersion: string;
}
