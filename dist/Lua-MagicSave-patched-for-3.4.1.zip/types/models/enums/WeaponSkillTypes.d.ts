export declare enum WeaponSkillTypes {
    PISTOL = "Pistol",
    REVOLVER = "Revolver",
    SMG = "SMG",
    ASSAULT = "Assault",
    SHOTGUN = "Shotgun",
    SNIPER = "Sniper",
    LMG = "LMG",
    HMG = "HMG",
    DMR = "DMR",
    LAUNCHER = "Launcher",
    ATTACHED_LAUNCHER = "AttachedLauncher",
    MELEE = "Melee"
}
