export declare class ErrorHandler {
    private logger;
    private readLine;
    constructor();
    handleCriticalError(err: any): void;
}
