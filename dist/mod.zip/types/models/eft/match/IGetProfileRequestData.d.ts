export interface IGetProfileRequestData {
    profileId: string;
}
