export interface IEndOfflineRaidRequestData {
    crc: number;
    exitStatus: string;
    exitName: any;
    raidSeconds: number;
}
