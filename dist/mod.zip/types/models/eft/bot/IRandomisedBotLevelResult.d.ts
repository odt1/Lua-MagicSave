export interface IRandomisedBotLevelResult {
    level: number;
    exp: number;
}
