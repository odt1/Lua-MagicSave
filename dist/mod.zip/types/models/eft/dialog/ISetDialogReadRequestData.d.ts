export interface ISetDialogReadRequestData {
    dialogs: string[];
}
