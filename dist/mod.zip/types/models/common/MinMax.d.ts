export interface MinMax {
    max: number;
    min: number;
}
