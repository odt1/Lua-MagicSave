export declare enum ExitStatus {
    SURVIVED = 0,
    KILLED = 1,
    LEFT = 2,
    RUNNER = 3,
    MISSINGINACTION = 4
}
