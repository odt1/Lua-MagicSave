export declare enum Traders {
    PRAPOR = "54cb50c76803fa8b248b4571",
    THERAPIST = "54cb57776803fa99248b456e",
    FENCE = "579dc571d53a0658a154fbec",
    SKIER = "58330581ace78e27b8b10cee",
    PEACEKEEPER = "5935c25fb3acc3127c3d8cd9",
    MECHANIC = "5a7c2eca46aef81a7ca2145d",
    RAGMAN = "5ac3b934156ae10c4430e83c",
    JAEGER = "5c0647fdd443bc2504c2d371"
}
