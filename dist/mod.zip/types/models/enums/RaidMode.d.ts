export declare enum RaidMode {
    ONLINE = "Online",
    LOCAL = "Local",
    COOP = "Coop"
}
